---
type: bot-memory
memory_type: operating-policy
bot: JJ_SopadangBot
created: 2026-05-16
updated: 2026-05-16
confidence: high
tags:
  - bot-memory
  - obsidian
  - operating-policy
---

# Bot Memory Folder Policy

Save this bot's durable memories in `BDAObsidian/00-Bot-Memory/JJ_SopadangBot/`.

Use the Telegram bot username as the folder name. Do not use internal profile names such as gateway, codexbot, dawny, or nan numbers as memory folder names.

